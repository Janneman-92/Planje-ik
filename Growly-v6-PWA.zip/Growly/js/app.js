import { loadState, saveState, resetState } from "./storage.js";
import { stages, badges, plantTypes, missions, messages } from "./data.js";
import { todayKey, yesterdayKey, escapeHtml, pickEmoji, random, getSeasonLabel, autoWeather } from "./utils.js";
import { initFocus } from "./focus.js";

const els = {};
let state = loadState();

document.addEventListener("DOMContentLoaded", boot);

function boot() {
  mapElements();
  bindEvents();
  initFocus({ onComplete: () => { state.growth += 2; saveState(state); render(); toast("Focusmoment voltooid +2 groei 🌿"); } });
  applyTheme();
  setTimeMood();
  render();

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
}

function mapElements() {
  [
    "gardenWorld","dayPart","headerLine","seasonChip","heroLine","themeBtn","focusBtn","nudgeBtn","weatherBtn","stageName","stageHint","plantEmoji",
    "plantStage","flower","butterfly","bird","sparkle","pond","bench","speech","doneCount","streakCount","growthCount","progressBar","dateLabel",
    "missionIcon","missionTitle","missionHint","missionProgress","habitList","addForm","habitInput","plantPicker","badges","monthGrid","bestStreak",
    "habitTotal","activeDays","settingTheme","settingWeather","settingFocus","settingExport","settingReset","themeLabel","weatherLabel","toast","tabbar"
  ].forEach(id => els[id] = document.getElementById(id));
}

function bindEvents() {
  els.themeBtn.addEventListener("click", toggleTheme);
  els.nudgeBtn.addEventListener("click", () => speak(random(messages)));
  els.weatherBtn.addEventListener("click", cycleWeather);
  els.addForm.addEventListener("submit", addHabit);

  els.settingTheme.addEventListener("click", toggleTheme);
  els.settingWeather.addEventListener("click", cycleWeather);
  els.settingFocus.addEventListener("click", () => document.getElementById("focusOverlay").classList.add("show"));
  els.settingExport.addEventListener("click", exportData);
  els.settingReset.addEventListener("click", reset);

  els.tabbar.querySelectorAll("button").forEach(btn => {
    btn.addEventListener("click", () => switchScreen(btn.dataset.screen));
  });
}

function switchScreen(name) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(`screen-${name}`).classList.add("active");
  els.tabbar.querySelectorAll("button").forEach(b => b.classList.toggle("active", b.dataset.screen === name));
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function doneToday() { return state.completions[todayKey()] || []; }
function currentStage() { return [...stages].reverse().find(s => state.growth >= s.min) || stages[0]; }
function currentMission() { return missions[new Date().getDate() % missions.length]; }

function render() {
  renderWorld();
  renderStats();
  renderPlant();
  renderMission();
  renderHabits();
  renderPlantPicker();
  renderBadges();
  renderMonth();
  renderSummary();
  renderHeroText();
  renderSettings();
}

function applyTheme() {
  document.documentElement.dataset.theme = state.theme;
  els.themeBtn.textContent = state.theme === "dark" ? "☀️" : "🌙";
}

function setTimeMood() {
  const hour = new Date().getHours();
  const part = hour < 6 ? "nacht" : hour < 12 ? "ochtend" : hour < 18 ? "middag" : "avond";
  const greeting = part === "nacht" ? "Goedenacht 🌙" : part === "ochtend" ? "Goedemorgen ☀️" : part === "middag" ? "Goedemiddag 🌤️" : "Goedenavond 🌇";
  els.dayPart.textContent = greeting;
  els.seasonChip.textContent = getSeasonLabel();
}

function renderWorld() {
  els.gardenWorld.dataset.weather = state.weather || autoWeather();
  const labels = { sunny: "☀️ Zon", rain: "🌧️ Regen", night: "🌙 Nacht" };
  els.weatherBtn.textContent = labels[state.weather] || "🌦️ Weer";
}

function renderStats() {
  const done = doneToday().length;
  const total = Math.max(1, state.habits.length);
  const percent = Math.round(done / total * 100);
  const stage = currentStage();

  els.doneCount.textContent = done;
  els.streakCount.textContent = state.streak;
  els.growthCount.textContent = state.growth;
  els.progressBar.style.width = `${percent}%`;
  els.stageName.textContent = stage.name;
  els.stageHint.textContent = stage.hint;
  els.dateLabel.textContent = new Intl.DateTimeFormat("nl-NL", { weekday: "short", day: "numeric", month: "short" }).format(new Date());
}

function renderHeroText() {
  const remaining = Math.max(0, state.habits.length - doneToday().length);
  els.headerLine.textContent = remaining === 0 ? "Je tuin straalt vandaag." : "Je tuin mist je.";
  els.heroLine.textContent = remaining === 0
    ? "Vandaag is compleet. Je plant heeft alles gekregen wat ze nodig had."
    : `Nog ${remaining} ${remaining === 1 ? "kleine gewoonte" : "kleine gewoontes"} en je tuin krijgt nieuwe energie.`;
}

function renderPlant() {
  const type = plantTypes.find(p => p.id === state.plantType) || plantTypes[0];
  els.plantStage.className = `plant-stage ${type.cls}`;
  els.plantEmoji.textContent = type.emoji;

  const g = Math.min(state.growth, 78);
  els.plantStage.style.setProperty("--stem-height", `${44 + g * 4.05}px`);
  els.plantStage.style.setProperty("--leaf-size", `${42 + Math.min(g, 30) * 2.05}px`);
  els.plantStage.style.setProperty("--leaf-opacity", Math.min(1, .18 + g / 10));

  if (state.plantType === "cactus") {
    els.plantStage.style.setProperty("--leaf-gradient", "linear-gradient(135deg, #7dbb6e, #306e4b)");
  } else if (state.plantType === "bonsai") {
    els.plantStage.style.setProperty("--leaf-gradient", "radial-gradient(circle at 30% 30%, #aad18c, #467842)");
  } else {
    els.plantStage.style.setProperty("--leaf-gradient", "linear-gradient(135deg, #8fc28a, #3f7647)");
  }

  els.flower.classList.toggle("show", state.growth >= 28 && state.plantType !== "cactus");
  els.butterfly.classList.toggle("show", state.growth >= 10);
  els.bird.classList.toggle("show", state.growth >= 18);
  els.sparkle.classList.toggle("show", state.growth >= 45);
  els.pond.classList.toggle("show", state.growth >= 34);
  els.bench.classList.toggle("show", state.growth >= 52);
}

function renderMission() {
  const mission = currentMission();
  const done = doneToday().length;
  els.missionIcon.textContent = mission.icon;
  els.missionTitle.textContent = mission.title;
  els.missionHint.textContent = mission.hint;
  els.missionProgress.textContent = `${Math.min(done, mission.target)}/${mission.target}`;
}

function renderHabits() {
  const done = new Set(doneToday());
  els.habitList.innerHTML = "";

  if (!state.habits.length) {
    els.habitList.innerHTML = '<div class="empty">Nog geen gewoontes. Voeg je eerste micro-gewoonte toe.</div>';
    return;
  }

  state.habits.forEach(h => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = `habit ${done.has(h.id) ? "done" : ""}`;
    row.innerHTML = `
      <span class="check">✓</span>
      <span class="emoji">${h.emoji || "🌱"}</span>
      <span class="habit-text"><strong>${escapeHtml(h.title)}</strong><span>${escapeHtml(h.subtitle || "Kleine stap, grote winst")}</span></span>
      <span class="delete-habit" role="button" aria-label="Verwijder gewoonte">×</span>
    `;
    row.addEventListener("click", e => {
      if (e.target.classList.contains("delete-habit")) {
        e.stopPropagation();
        deleteHabit(h.id);
      } else {
        toggleHabit(h.id);
      }
    });
    els.habitList.appendChild(row);
  });
}

function renderPlantPicker() {
  els.plantPicker.innerHTML = "";
  plantTypes.forEach(p => {
    const unlocked = state.growth >= p.min;
    const el = document.createElement("button");
    el.type = "button";
    el.className = `plant-option ${unlocked ? "unlocked" : ""} ${state.plantType === p.id ? "active" : ""}`;
    el.title = unlocked ? p.title : `Vrij bij ${p.min} groei`;
    el.textContent = unlocked ? p.emoji : "🔒";
    el.addEventListener("click", () => {
      if (!unlocked) return toast(`Nog ${p.min - state.growth} groei nodig`);
      state.plantType = p.id;
      saveState(state);
      render();
      toast(`${p.title} gekozen`);
    });
    els.plantPicker.appendChild(el);
  });
}

function renderBadges() {
  els.badges.innerHTML = "";
  badges.forEach(b => {
    const unlocked = b.streak ? (state.streak >= b.streak || state.bestStreak >= b.streak) : state.growth >= b.min;
    const el = document.createElement("div");
    el.className = `badge ${unlocked ? "unlocked" : ""}`;
    el.title = unlocked ? b.title : "Nog vergrendeld";
    el.textContent = unlocked ? b.icon : "🔒";
    els.badges.appendChild(el);
  });
}

function renderMonth() {
  const now = new Date();
  const days = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  els.monthGrid.innerHTML = "";
  for (let day = 1; day <= days; day++) {
    const d = new Date(now.getFullYear(), now.getMonth(), day);
    const key = d.toISOString().slice(0, 10);
    const active = (state.completions[key] || []).length > 0;
    const dot = document.createElement("div");
    dot.className = `day-dot ${active ? "active" : ""} ${key === todayKey() ? "today" : ""}`;
    dot.textContent = day;
    els.monthGrid.appendChild(dot);
  }
}

function renderSummary() {
  els.bestStreak.textContent = `${state.bestStreak || 0} dagen`;
  els.habitTotal.textContent = state.habits.length;
  els.activeDays.textContent = Object.values(state.completions).filter(v => Array.isArray(v) && v.length && !String(v[0]).includes("bonus")).length;
}

function renderSettings() {
  els.themeLabel.textContent = state.theme === "dark" ? "Aan" : "Uit";
  els.weatherLabel.textContent = ({ sunny: "Zon", rain: "Regen", night: "Nacht" })[state.weather] || "Auto";
}

function toggleHabit(id) {
  const key = todayKey();
  const set = new Set(state.completions[key] || []);

  if (set.has(id)) {
    set.delete(id);
    state.growth = Math.max(0, state.growth - 1);
    speak("Geen probleem. Je kunt hem straks opnieuw doen.");
  } else {
    set.add(id);
    state.growth += 1;
    speak(random(messages));
    checkMissionBonus(set.size);
    toast("Je tuin groeit 🌿");
  }

  state.completions[key] = [...set];
  updateStreak();
  saveState(state);
  render();
}

function checkMissionBonus(doneCount) {
  const mission = currentMission();
  const key = todayKey() + "-mission";
  if (doneCount >= mission.target && !state.completions[key]) {
    state.growth += 2;
    state.completions[key] = ["bonus"];
    toast("Dagmissie voltooid +2 groei ✨");
  }
}

function updateStreak() {
  const complete = state.habits.length > 0 && doneToday().length === state.habits.length;
  if (!complete || state.lastCompletedDay === todayKey()) return;
  state.streak = state.lastCompletedDay === yesterdayKey() ? state.streak + 1 : 1;
  state.bestStreak = Math.max(state.bestStreak || 0, state.streak);
  state.lastCompletedDay = todayKey();
}

function addHabit(e) {
  e.preventDefault();
  const title = els.habitInput.value.trim();
  if (!title) return;
  state.habits.push({ id: crypto.randomUUID(), title, emoji: pickEmoji(title), subtitle: "Nieuwe micro-gewoonte" });
  els.habitInput.value = "";
  saveState(state);
  render();
  speak(`Nieuwe gewoonte toegevoegd: ${title}.`);
  toast("Gewoonte toegevoegd");
}

function deleteHabit(id) {
  const habit = state.habits.find(h => h.id === id);
  if (!habit) return;
  if (!confirm(`"${habit.title}" verwijderen?`)) return;
  state.habits = state.habits.filter(h => h.id !== id);
  Object.keys(state.completions).forEach(k => state.completions[k] = (state.completions[k] || []).filter(x => x !== id));
  saveState(state);
  render();
  toast("Gewoonte verwijderd");
}

function toggleTheme() {
  state.theme = state.theme === "dark" ? "light" : "dark";
  saveState(state);
  applyTheme();
  renderSettings();
  toast(state.theme === "dark" ? "Donkere modus aan" : "Lichte modus aan");
}

function cycleWeather() {
  const order = ["sunny", "rain", "night"];
  state.weather = order[(order.indexOf(state.weather) + 1) % order.length];
  saveState(state);
  renderWorld();
  renderSettings();
  toast(({ sunny: "Zon in je tuin", rain: "Zachte regen", night: "Nachtmodus wereld" })[state.weather]);
}

function exportData() {
  navigator.clipboard?.writeText(JSON.stringify(state, null, 2));
  toast("Export gekopieerd");
}

function reset() {
  if (!confirm("Weet je zeker dat je Growly wilt resetten?")) return;
  resetState();
  state = loadState();
  applyTheme();
  setTimeMood();
  render();
  speak("Een nieuwe tuin. Een nieuwe start.");
  toast("App gereset");
}

function speak(text) { els.speech.textContent = text; }

function toast(text) {
  els.toast.textContent = text;
  els.toast.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => els.toast.classList.remove("show"), 2200);
}
