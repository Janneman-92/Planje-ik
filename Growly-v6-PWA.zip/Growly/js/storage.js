import { defaultHabits } from "./data.js";
import { autoWeather } from "./utils.js";

export const STORAGE_KEY = "growly.project.v6";

export function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return freshState();

  try {
    const s = JSON.parse(raw);
    return {
      habits: Array.isArray(s.habits) && s.habits.length ? s.habits : defaultHabits(),
      completions: s.completions || {},
      growth: Number(s.growth || 0),
      streak: Number(s.streak || 0),
      bestStreak: Number(s.bestStreak || 0),
      lastCompletedDay: s.lastCompletedDay || null,
      theme: s.theme || "light",
      weather: s.weather || autoWeather(),
      plantType: s.plantType || "sprout"
    };
  } catch {
    localStorage.removeItem(STORAGE_KEY);
    return freshState();
  }
}

export function freshState() {
  return {
    habits: defaultHabits(),
    completions: {},
    growth: 0,
    streak: 0,
    bestStreak: 0,
    lastCompletedDay: null,
    theme: "light",
    weather: autoWeather(),
    plantType: "sprout"
  };
}

export function saveState(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function resetState() {
  localStorage.removeItem(STORAGE_KEY);
}
