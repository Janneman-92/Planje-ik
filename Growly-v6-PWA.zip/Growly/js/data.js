const uid = () => crypto.randomUUID ? crypto.randomUUID() : "id-" + Date.now() + Math.random();

export function defaultHabits() {
  return [
    { id: uid(), title: "Water drinken", emoji: "💧", subtitle: "1 glas bewust drinken" },
    { id: uid(), title: "10 minuten focus", emoji: "⏱️", subtitle: "Studeren, bouwen of lezen" },
    { id: uid(), title: "Korte wandeling", emoji: "🚶", subtitle: "Even naar buiten" },
    { id: uid(), title: "Rustmoment", emoji: "🧘", subtitle: "1 minuut ademhalen" }
  ];
}

export const stages = [
  { name: "Zaadje", hint: "Begin met één stap", min: 0 },
  { name: "Spruit", hint: "De eerste groei", min: 3 },
  { name: "Jong plantje", hint: "Je bouwt ritme", min: 8 },
  { name: "Sterke plant", hint: "Mooi momentum", min: 16 },
  { name: "Bloei", hint: "Je tuin leeft", min: 28 },
  { name: "Magische groei", hint: "Zeldzame energie", min: 45 }
];

export const badges = [
  { icon: "🌱", title: "Eerste stap", min: 1 },
  { icon: "🪴", title: "Spruit", min: 5 },
  { icon: "🦋", title: "Vlinder", min: 10 },
  { icon: "🐦", title: "Vogel", min: 18 },
  { icon: "🌸", title: "Bloei", min: 28 },
  { icon: "✨", title: "Magie", min: 45 },
  { icon: "🔥", title: "Streak 7", streak: 7 },
  { icon: "🌳", title: "Tuinier", min: 65 }
];

export const plantTypes = [
  { id: "sprout", emoji: "🌱", title: "Spruit", min: 0, cls: "" },
  { id: "flower", emoji: "🌸", title: "Bloem", min: 12, cls: "" },
  { id: "cactus", emoji: "🌵", title: "Cactus", min: 22, cls: "plant-cactus" },
  { id: "bonsai", emoji: "🌳", title: "Bonsai", min: 36, cls: "plant-bonsai" }
];

export const missions = [
  { icon: "💧", title: "Geef je tuin water", hint: "Vink 2 gewoontes af vandaag", target: 2 },
  { icon: "☀️", title: "Laat licht binnen", hint: "Vink 3 gewoontes af vandaag", target: 3 },
  { icon: "🌿", title: "Versterk de wortels", hint: "Vink 1 gewoonte af vandaag", target: 1 }
];

export const messages = [
  "Goed gedaan. Niet groot, wel belangrijk.",
  "Je hebt vandaag iets voor jezelf gedaan. Dat telt.",
  "Kleine stappen maken sterke wortels.",
  "Ik groei mee met jouw ritme.",
  "Perfect hoeft niet. Aanwezig zijn is genoeg.",
  "Je tuin merkt dat je er bent.",
  "Nog één stap en vandaag voelt weer iets lichter."
];
