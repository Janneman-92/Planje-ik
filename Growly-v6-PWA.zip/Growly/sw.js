const CACHE_NAME = "growly-v6";
const ASSETS = [
  "./",
  "./index.html",
  "./css/app.css",
  "./css/garden.css",
  "./css/animations.css",
  "./js/app.js",
  "./js/storage.js",
  "./js/data.js",
  "./js/utils.js",
  "./js/focus.js",
  "./manifest.json",
  "./assets/icons/icon.svg"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)));
});

self.addEventListener("fetch", event => {
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request)));
});
