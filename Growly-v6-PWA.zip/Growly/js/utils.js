export function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

export function yesterdayKey() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().slice(0, 10);
}

export function autoWeather() {
  const h = new Date().getHours();
  if (h < 6 || h >= 21) return "night";
  return "sunny";
}

export function getSeasonLabel() {
  const hour = new Date().getHours();
  const part = hour < 6 ? "nacht" : hour < 12 ? "ochtend" : hour < 18 ? "middag" : "avond";
  const month = new Date().getMonth() + 1;
  const season = month >= 3 && month <= 5 ? "Lente" : month <= 8 ? "Zomer" : month <= 11 ? "Herfst" : "Winter";
  const icon = part === "nacht" ? "🌙" : season === "Winter" ? "❄️" : part === "avond" ? "🌇" : "🌤️";
  return `${icon} ${season}-${part}`;
}

export function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function pickEmoji(text) {
  const t = text.toLowerCase();
  if (t.includes("water")) return "💧";
  if (t.includes("lees") || t.includes("boek")) return "📖";
  if (t.includes("stud") || t.includes("focus") || t.includes("werk")) return "⏱️";
  if (t.includes("wandel") || t.includes("loop")) return "🚶";
  if (t.includes("slaap")) return "🛏️";
  if (t.includes("sport") || t.includes("fitness")) return "🏋️";
  if (t.includes("medicatie") || t.includes("pil")) return "💊";
  if (t.includes("adem") || t.includes("rust") || t.includes("medit")) return "🧘";
  if (t.includes("schrijf") || t.includes("journal")) return "✍️";
  return "🌱";
}

export function escapeHtml(str) {
  return String(str)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}
