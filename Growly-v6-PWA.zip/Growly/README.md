# Growly Garden

Een premium micro-gewoontes PWA prototype.

## Openen
Open `index.html` direct in je browser.

## Projectstructuur
- `index.html` — app-layout
- `css/app.css` — algemene UI
- `css/garden.css` — levende tuin
- `css/animations.css` — animaties
- `js/app.js` — hoofdlogica
- `js/storage.js` — lokale opslag
- `js/data.js` — planten, badges, missies
- `js/focus.js` — focusmodus
- `manifest.json` — PWA metadata
- `sw.js` — offline cache

## Features
- 5 tabbladen: Tuin, Vandaag, Ontdekken, Groei, Meer
- Lokale opslag via localStorage
- Levende tuin met groei, dieren en decoraties
- Plantkeuze
- Dagmissies
- Focusmodus
- Weerwissel
- Donkere modus
- PWA manifest + service worker
