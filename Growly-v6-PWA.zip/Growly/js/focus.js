let timerInterval = null;
let timerSeconds = 300;

export function initFocus({ onComplete }) {
  const overlay = document.getElementById("focusOverlay");
  const start = document.getElementById("startTimerBtn");
  const close = document.getElementById("closeFocusBtn");
  const timer = document.getElementById("timer");
  const focusBtn = document.getElementById("focusBtn");

  focusBtn.addEventListener("click", () => overlay.classList.add("show"));
  close.addEventListener("click", () => {
    overlay.classList.remove("show");
    stopTimer(start, timer);
  });

  start.addEventListener("click", () => {
    if (timerInterval) return;
    start.textContent = "Bezig...";
    timerInterval = setInterval(() => {
      timerSeconds -= 1;
      updateTimerText(timer);
      if (timerSeconds <= 0) {
        stopTimer(start, timer);
        overlay.classList.remove("show");
        onComplete();
      }
    }, 1000);
  });
}

function stopTimer(start, timer) {
  clearInterval(timerInterval);
  timerInterval = null;
  timerSeconds = 300;
  start.textContent = "Start";
  updateTimerText(timer);
}

function updateTimerText(timer) {
  const m = String(Math.floor(timerSeconds / 60)).padStart(2, "0");
  const s = String(timerSeconds % 60).padStart(2, "0");
  timer.textContent = `${m}:${s}`;
}
